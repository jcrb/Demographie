France, Total National Population 
