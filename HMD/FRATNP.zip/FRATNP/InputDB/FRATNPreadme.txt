France, Total National Population 
