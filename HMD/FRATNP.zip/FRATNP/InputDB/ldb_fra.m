function ldb_fra=ldb_fra()
clear all;
global nofluctM nofluctF

nofluctM=1816:1950;
nofluctF=1816:1950;
%nofluctM=[];
%nofluctF=[];
indb_input('FRATNP');
load FRATNP;

d=selif(deaths, deaths(:, end)~=0);
deaths=deaths(:,1:end-1);
p=selif(population, population(:, end)==1);
p=p(:,1:end-1);
births=selif(births, births(:, end)==1);
births=births(:,1:end-1);

clear deaths;



%p=p(p(:,5)<2009,:);
births=selif(births, (births(:,1)~=20 | births(:,3)~=1899) & (births(:,1)~=10 | births(:,3)~=1860) & (births(:,1)~=15 | births(:,3)~=1868));

disp('split RR');
d=d_s5x1(d);
d=d_s1x1tn(d, births, tadj);
d=d_ma0(d);
d=d_svv(d);
d=d_long(d);

disp('distribution of unknown');
d=d_unk(d);

save rsd0
%open age interval
disp('open age interval');
d=d_soainew(d);


save rsd


disp('population');

%p=selif(population, population(:,3)~=300 & population(:,2)~=3 & (population(:,5)~=1914 | population(:,1)~=30) & (population(:,5)~=1920 | population(:,1)~=40) & (population(:,5)~=1939 | population(:,1)~=50) & (population(:,5)~=1943 | population(:,1)~=60) & (population(:,5)~=1945 | population(:,1)~=70) & (population(:,5)~=1946 | population(:,1)~=80));
clear population;
p=p_ict(p, d, births,tadj);
disp('Extinct cohort method');
p=p_srecmt(p, d, tadj);


save rsp

ldb_output(d, p, 'mFRATNP.txt', 'fFRATNP.txt', births);
d_printRA('fratnp','France');